import sys, urllib.parse, urllib.request, json
import xbmcgui, xbmcplugin, xbmcaddon, xbmc

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])

def get_setting(id):
    return ADDON.getSetting(id)

def set_setting(id, value):
    ADDON.setSetting(id, value)

def get_group_size():
    idx = get_setting('ep_per_page')
    mapping = {"0": 25, "1": 50, "2": 75, "3": 100}
    return mapping.get(idx, 50)

def get_data(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            return json.loads(response.read().decode('utf-8'))
    except: return {}

def get_url(**kwargs):
    return sys.argv[0] + '?' + urllib.parse.urlencode(kwargs)

def get_image(item):
    """Logic lấy ảnh: Ép buộc dùng img.ophim.live cho link tương đối"""
    p_url = item.get('poster_url', '')
    if not p_url: p_url = item.get('thumb_url', '')
    if not p_url: return ""

    if p_url.startswith('http'):
        final_img = p_url
    else:
        # Ép buộc ghép với domain ophim.live
        final_img = f"https://img.ophim.live/{p_url.lstrip('/')}"
    
    # Ghi log để xác nhận link
    xbmc.log(f"OPHIM_IMAGE_LOG: {final_img}", xbmc.LOGINFO)
    return final_img

# --- Menu chính ---
def main_menu():
    add_directory_item("[COLOR yellow]🔍 TÌM KIẾM[/COLOR]", get_url(action='search'))
    add_directory_item("[COLOR lime]🎬 PHIM MỚI CẬP NHẬT[/COLOR]", get_url(action='home_list'))
    add_directory_item("[COLOR orange]🌍 XEM THEO QUỐC GIA[/COLOR]", get_url(action='list_countries'))
    add_directory_item("[COLOR cyan]📁 XEM THEO THỂ LOẠI[/COLOR]", get_url(action='list_genres'))
    add_directory_item("[COLOR gray]🕒 LỊCH SỬ XEM[/COLOR]", get_url(action='show_history'))
    xbmcplugin.endOfDirectory(HANDLE)

def list_movies(category='phim-moi-cap-nhat', page=1, query='', type='danh-sach'):
    domain = get_setting('api_domain')
    page = int(page)
    limit = 50 
    
    if query:
        url = f"{domain}/v1/api/tim-kiem?keyword={urllib.parse.quote(query)}&page={page}&limit={limit}"
    else:
        url = f"{domain}/v1/api/{type}/{category}?page={page}&limit={limit}"
    
    resp = get_data(url)
    data = resp.get('data', {})
    items = data.get('items', [])
    
    xbmcplugin.setContent(HANDLE, 'movies')

    for item in items:
        t = item.get('name')
        s = item.get('slug')
        img = get_image(item)
        add_directory_item(t, get_url(action='movie_detail', slug=s), img)

    # Phân trang
    pagination = data.get('params', {}).get('pagination', {})
    total_items = int(pagination.get('totalItems', 0))
    current_page = int(pagination.get('currentPage', page))
    total_pages = (total_items + limit - 1) // limit 

    if current_page < total_pages:
        next_page = current_page + 1
        label = f"[COLOR yellow]>> TRANG KẾ TIẾP ({next_page}/{total_pages}) >>[/COLOR]"
        u = get_url(action='list_movies', category=category, page=next_page, query=query, type=type)
        add_directory_item(label, u, is_folder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def movie_detail(slug):
    domain = get_setting('api_domain')
    movie_data = get_data(f"{domain}/v1/api/phim/{slug}")
    item_data = movie_data.get('data', {}).get('item', {})
    if not item_data: return
    
    poster = get_image(item_data)
    save_history(item_data.get('name'), slug, poster)
    
    xbmcplugin.setContent(HANDLE, 'episodes')
    
    group_size = get_group_size()
    episodes = item_data.get('episodes', [])

    for s_idx, server in enumerate(episodes):
        s_name = server.get('server_name')
        data_eps = server.get('server_data', [])
        total = len(data_eps)
        
        if total > group_size:
            for i in range(0, total, group_size):
                label = f"[{s_name}] Tập {i+1} - {min(i+group_size, total)}"
                u = get_url(action='list_episodes', slug=slug, s_idx=s_idx, start=i, end=min(i+group_size, total))
                add_directory_item(label, u, poster, is_folder=True)
        else:
            for ep in data_eps:
                ep_label = f"[{s_name}] {ep.get('filename', ep.get('name'))}"
                add_episode_item(ep_label, ep['link_m3u8'], item_data, poster)
                
    xbmcplugin.endOfDirectory(HANDLE)

def list_episodes(slug, s_idx, start, end):
    domain = get_setting('api_domain')
    movie = get_data(f"{domain}/v1/api/phim/{slug}").get('data', {}).get('item', {})
    server = movie.get('episodes', [])[int(s_idx)]
    data_eps = server.get('server_data', [])[int(start):int(end)]
    
    xbmcplugin.setContent(HANDLE, 'episodes')
    poster = get_image(movie)
    s_name = server.get('server_name')
    for ep in data_eps:
        ep_label = f"[{s_name}] {ep.get('filename', ep.get('name'))}"
        add_episode_item(ep_label, ep['link_m3u8'], movie, poster)
    xbmcplugin.endOfDirectory(HANDLE)

def add_episode_item(name, link, movie, thumb):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': thumb, 'icon': thumb, 'fanart': thumb})
    
    plot = movie.get('content', '').replace('<p>','').replace('</p>','')
    info = {
        'plot': plot, 
        'title': name, 
        'mediatype': 'episode', 
        'tvshowtitle': movie.get('name')
    }
    li.setInfo('video', info)
    li.setProperty('IsPlayable', 'true')
    
    xbmcplugin.addDirectoryItem(HANDLE, link, li, False)

def add_directory_item(name, url, thumb='', is_folder=True):
    li = xbmcgui.ListItem(label=name)
    if thumb: li.setArt({'thumb': thumb, 'icon': thumb, 'fanart': thumb})
    xbmcplugin.addDirectoryItem(HANDLE, url, li, is_folder)

# --- Các hàm khác ---
def list_countries():
    domain = get_setting('api_domain')
    resp = get_data(f"{domain}/v1/api/quoc-gia")
    for item in resp.get('data', {}).get('items', []):
        add_directory_item(item.get('name'), get_url(action='list_movies', category=item.get('slug'), type='quoc-gia', page=1))
    xbmcplugin.endOfDirectory(HANDLE)

def list_genres():
    domain = get_setting('api_domain')
    resp = get_data(f"{domain}/v1/api/the-loai")
    for item in resp.get('data', {}).get('items', []):
        add_directory_item(item.get('name'), get_url(action='list_movies', category=item.get('slug'), type='the-loai', page=1))
    xbmcplugin.endOfDirectory(HANDLE)

def home_list():
    domain = get_setting('api_domain')
    resp = get_data(f"{domain}/v1/api/home")
    for item in resp.get('data', {}).get('items', []):
        add_directory_item(item.get('name'), get_url(action='list_movies', category=item.get('slug'), type='danh-sach', page=1))
    xbmcplugin.endOfDirectory(HANDLE)

def search():
    q = xbmcgui.Dialog().input('Tìm phim...', type=xbmcgui.INPUT_ALPHANUM)
    if q: list_movies(query=q, page=1)

def save_history(title, slug, thumb):
    try:
        h_str = get_setting('history')
        history = json.loads(h_str) if h_str else []
    except: history = []
    history = [i for i in history if i['slug'] != slug]
    history.insert(0, {'title': title, 'slug': slug, 'thumb': thumb})
    set_setting('history', json.dumps(history[:20]))

def show_history():
    add_directory_item("[COLOR red]❌ XÓA LỊCH SỬ[/COLOR]", get_url(action='clear_history'))
    try:
        history = json.loads(get_setting('history') or '[]')
    except: history = []
    for item in history:
        add_directory_item(f"🕒 {item['title']}", get_url(action='movie_detail', slug=item['slug']), item['thumb'])
    xbmcplugin.endOfDirectory(HANDLE)

# --- Router ---
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
act = params.get('action')
if not act: main_menu()
elif act == 'home_list': home_list()
elif act == 'list_countries': list_countries()
elif act == 'list_genres': list_genres()
elif act == 'list_movies': list_movies(params.get('category'), params.get('page', 1), params.get('query', ''), params.get('type', 'danh-sach'))
elif act == 'movie_detail': movie_detail(params.get('slug'))
elif act == 'list_episodes': list_episodes(params['slug'], params['s_idx'], params['start'], params['end'])
elif act == 'search': search()
elif act == 'show_history': show_history()
elif act == 'clear_history':
    set_setting('history', '[]')
    xbmcplugin.endOfDirectory(HANDLE)
