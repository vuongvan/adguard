import sys, urllib.parse, urllib.request, json, re
import xbmcgui, xbmcplugin, xbmcaddon, xbmc

# Khởi tạo Addon
ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'

def get_setting(id): return ADDON.getSetting(id)
def set_setting(id, value): ADDON.setSetting(id, value)
def get_url(**kwargs): return sys.argv[0] + '?' + urllib.parse.urlencode(kwargs)

def get_data(url):
    """Sử dụng urllib.request thay thế cho requests"""
    try:
        req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
        with urllib.request.urlopen(req, timeout=10) as response:
            return json.loads(response.read().decode('utf-8'))
    except Exception as e:
        xbmc.log(f"DEBUG_ERROR_FETCH: {str(e)}", xbmc.LOGERROR)
        return {}

def get_image(item):
    """Logic ghép chuỗi ảnh chuẩn xác, tự bù uploads/movies/ nếu thiếu"""
    try:
        img_path = item.get('thumb_url', '') or item.get('poster_url', '')
        if img_path:
            # 1. Xử lý link tuyệt đối (bắt đầu bằng http)
            if img_path.startswith('http'):
                filename = img_path.split('/')[-1]
                final_url = f"https://img.ophim.live/uploads/movies/{filename}"
            # 2. Xử lý link tương đối
            else:
                clean_path = img_path.lstrip('/')
                if 'uploads/' not in clean_path:
                    final_url = f"https://img.ophim.live/uploads/movies/{clean_path}"
                else:
                    final_url = f"https://img.ophim.live/{clean_path}"
            return final_url
        
        # Fallback bằng slug nếu không có key ảnh
        slug = item.get('slug', '')
        if slug: return f"https://img.ophim.live/uploads/movies/{slug}-thumb.jpg"
    except: pass
    return ""

def main_menu():
    add_directory_item("[COLOR yellow]🔍 TÌM KIẾM[/COLOR]", get_url(action='search'))
    add_directory_item("[COLOR lime]🎬 PHIM MỚI CẬP NHẬT[/COLOR]", get_url(action='list_movies', category='phim-moi-cap-nhat', type='danh-sach', page=1))
    add_directory_item("[COLOR orange]🌍 XEM THEO QUỐC GIA[/COLOR]", get_url(action='list_countries'))
    add_directory_item("[COLOR cyan]📁 XEM THEO THỂ LOẠI[/COLOR]", get_url(action='list_genres'))
    add_directory_item("[COLOR gray]🕒 LỊCH SỬ XEM[/COLOR]", get_url(action='show_history'))
    xbmcplugin.endOfDirectory(HANDLE)

def list_movies(category='phim-moi-cap-nhat', page=1, query='', type='danh-sach'):
    domain = get_setting('api_domain')
    page = int(page)
    limit = 40
    if query:
        url = f"{domain}/v1/api/tim-kiem?keyword={urllib.parse.quote(query)}&page={page}&limit={limit}"
    else:
        url = f"{domain}/v1/api/{type}/{category}?page={page}&limit={limit}"
    
    resp = get_data(url)
    items = resp.get('data', {}).get('items', [])
    xbmcplugin.setContent(HANDLE, 'movies')
    
    for item in items:
        add_directory_item(item.get('name'), get_url(action='movie_detail', slug=item.get('slug')), get_image(item))
    
    pagination = resp.get('data', {}).get('params', {}).get('pagination', {})
    total_items = int(pagination.get('totalItems', 0))
    total_pages = (total_items + limit - 1) // limit 
    if page < total_pages:
        add_directory_item(f"[COLOR yellow]>> TRANG {page+1}/{total_pages} >>[/COLOR]", get_url(action='list_movies', category=category, page=page+1, query=query, type=type))
    xbmcplugin.endOfDirectory(HANDLE)

def movie_detail(slug):
    domain = get_setting('api_domain')
    movie_data = get_data(f"{domain}/v1/api/phim/{slug}")
    item_data = movie_data.get('data', {}).get('item', {})
    if not item_data: return
    
    poster = get_image(item_data)
    save_history(item_data.get('name'), slug, poster)
    xbmcplugin.setContent(HANDLE, 'episodes')
    
    try:
        mapping = {"0": 25, "1": 50, "2": 75, "3": 100}
        group_size = mapping.get(get_setting('ep_per_page'), 50)
    except: group_size = 50
    
    episodes = item_data.get('episodes', [])
    for s_idx, server in enumerate(episodes):
        s_name = server.get('server_name')
        data_eps = server.get('server_data', [])
        if len(data_eps) > group_size:
            for i in range(0, len(data_eps), group_size):
                end = min(i + group_size, len(data_eps))
                add_directory_item(f"[{s_name}] Tập {i+1} - {end}", get_url(action='list_episodes', slug=slug, s_idx=s_idx, start=i, end=end), poster)
        else:
            for ep in data_eps:
                add_episode_item(f"[{s_name}] {ep.get('filename', ep.get('name'))}", ep['link_m3u8'], item_data, poster)
    xbmcplugin.endOfDirectory(HANDLE)

def list_episodes(slug, s_idx, start, end):
    domain = get_setting('api_domain')
    item_data = get_data(f"{domain}/v1/api/phim/{slug}").get('data', {}).get('item', {})
    server = item_data.get('episodes', [])[int(s_idx)]
    data_eps = server.get('server_data', [])[int(start):int(end)]
    xbmcplugin.setContent(HANDLE, 'episodes')
    poster = get_image(item_data)
    for ep in data_eps:
        add_episode_item(f"[{server.get('server_name')}] {ep.get('filename', ep.get('name'))}", ep['link_m3u8'], item_data, poster)
    xbmcplugin.endOfDirectory(HANDLE)

# --- Các hàm phụ trợ Giao diện ---
def add_episode_item(name, link, movie, thumb):
    li = xbmcgui.ListItem(label=name)
    li.setArt({'thumb': thumb, 'icon': thumb, 'fanart': thumb})
    plot = movie.get('content', '').replace('<p>','').replace('</p>','')
    li.setInfo('video', {'plot': plot, 'title': name, 'mediatype': 'episode'})
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(HANDLE, link, li, False)

def add_directory_item(name, url, thumb='', is_folder=True):
    li = xbmcgui.ListItem(label=name)
    if thumb: li.setArt({'thumb': thumb, 'icon': thumb, 'fanart': thumb})
    xbmcplugin.addDirectoryItem(HANDLE, url, li, is_folder)

# --- Tính năng Hệ thống ---
def save_history(title, slug, thumb):
    try:
        history = json.loads(get_setting('history') or '[]')
        history = [i for i in history if i.get('slug') != slug]
        history.insert(0, {'title': title, 'slug': slug, 'thumb': thumb})
        set_setting('history', json.dumps(history[:20]))
    except: pass

def show_history():
    add_directory_item("[COLOR red]❌ XÓA LỊCH SỬ[/COLOR]", get_url(action='clear_history'))
    try: history = json.loads(get_setting('history') or '[]')
    except: history = []
    for item in history:
        add_directory_item(f"🕒 {item['title']}", get_url(action='movie_detail', slug=item['slug']), item['thumb'])
    xbmcplugin.endOfDirectory(HANDLE)

def list_countries():
    resp = get_data(f"{get_setting('api_domain')}/v1/api/quoc-gia")
    for item in resp.get('data', {}).get('items', []):
        add_directory_item(item.get('name'), get_url(action='list_movies', category=item.get('slug'), type='quoc-gia', page=1))
    xbmcplugin.endOfDirectory(HANDLE)

def list_genres():
    resp = get_data(f"{get_setting('api_domain')}/v1/api/the-loai")
    for item in resp.get('data', {}).get('items', []):
        add_directory_item(item.get('name'), get_url(action='list_movies', category=item.get('slug'), type='the-loai', page=1))
    xbmcplugin.endOfDirectory(HANDLE)

def search():
    q = xbmcgui.Dialog().input('Tìm phim...', type=xbmcgui.INPUT_ALPHANUM)
    if q: list_movies(query=q, page=1)

# --- Điều hướng (Router) ---
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
act = params.get('action')
if not act: main_menu()
elif act == 'list_movies': list_movies(params.get('category'), params.get('page', 1), params.get('query', ''), params.get('type', 'danh-sach'))
elif act == 'movie_detail': movie_detail(params.get('slug'))
elif act == 'list_episodes': list_episodes(params['slug'], params['s_idx'], params['start'], params['end'])
elif act == 'list_countries': list_countries()
elif act == 'list_genres': list_genres()
elif act == 'search': search()
elif act == 'show_history': show_history()
elif act == 'clear_history':
    set_setting('history', '[]')
    xbmc.executebuiltin("Container.Refresh")
