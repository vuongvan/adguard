import sys
import json
import urllib.request
import urllib.parse
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc

# Khởi tạo Add-on
ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
URL_SCRIPT = sys.argv[0]

def get_setting_domain():
    val = ADDON.getSetting('api_domain')
    return val.strip('/') if val else "https://phimapi.com"

def get_setting_ep_step():
    try:
        idx = ADDON.getSetting('ep_per_page')
        steps = [25, 50, 75, 100]
        if idx == "" or not str(idx).isdigit():
            return 50
        return steps[int(idx)]
    except:
        return 50

def get_data(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            return json.loads(response.read().decode('utf-8'))
    except:
        return None

def list_main_menu():
    # 1. Tìm kiếm
    xbmcplugin.addDirectoryItem(HANDLE, f"{URL_SCRIPT}?action=search", xbmcgui.ListItem(label="[ 🔍 TÌM KIẾM PHIM ]"), True)
    
    # 2. Phim mới cập nhật
    xbmcplugin.addDirectoryItem(HANDLE, f"{URL_SCRIPT}?action=list_latest&page=1", xbmcgui.ListItem(label="[ 🔥 PHIM MỚI CẬP NHẬT ]"), True)
    
    # 3. Thể loại & Quốc gia
    xbmcplugin.addDirectoryItem(HANDLE, f"{URL_SCRIPT}?action=browse&type=the-loai", xbmcgui.ListItem(label="[ 📂 XEM THEO THỂ LOẠI ]"), True)
    xbmcplugin.addDirectoryItem(HANDLE, f"{URL_SCRIPT}?action=browse&type=quoc-gia", xbmcgui.ListItem(label="[ 🌍 XEM THEO QUỐC GIA ]"), True)
    
    # 4. Cài đặt
    xbmcplugin.addDirectoryItem(HANDLE, f"{URL_SCRIPT}?action=open_settings", xbmcgui.ListItem(label="[ ⚙️ CÀI ĐẶT HỆ THỐNG ]"), False)

    # 5. Lịch sử
    try:
        history = json.loads(ADDON.getSetting('history') or '[]')
        if history:
            xbmcplugin.addDirectoryItem(HANDLE, "", xbmcgui.ListItem(label="--- PHIM ĐÃ XEM GẦN ĐÂY ---"), False)
            for item in history:
                url = f"{URL_SCRIPT}?action=list_episodes&slug={item['slug']}"
                xbmcplugin.addDirectoryItem(HANDLE, url, xbmcgui.ListItem(label=f"🕒 {item['name']}"), True)
    except: pass
            
    xbmcplugin.endOfDirectory(HANDLE)

def list_latest_movies(page):
    domain = get_setting_domain()
    data = get_data(f"{domain}/danh-sach/phim-moi-cap-nhat?page={page}")
    if data and data.get('status') is True:
        for m in data.get('items', []):
            li = xbmcgui.ListItem(label=m['name'])
            li.setArt({'thumb': m['thumb_url'], 'poster': m['poster_url']})
            li.setInfo('video', {'title': m['name'], 'year': m.get('year', '')})
            xbmcplugin.addDirectoryItem(HANDLE, f"{URL_SCRIPT}?action=list_episodes&slug={m['slug']}", li, True)
            
        li_next = xbmcgui.ListItem(label=">> TRANG KẾ TIẾP")
        xbmcplugin.addDirectoryItem(HANDLE, f"{URL_SCRIPT}?action=list_latest&page={int(page)+1}", li_next, True)

    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.endOfDirectory(HANDLE)

def browse_categories(api_type):
    domain = get_setting_domain()
    data = get_data(f"{domain}/{api_type}")
    if data:
        for item in data:
            url = f"{URL_SCRIPT}?action=list_movies&mode={api_type}&slug={item['slug']}&page=1"
            xbmcplugin.addDirectoryItem(HANDLE, url, xbmcgui.ListItem(label=item['name']), True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_movies(slug, page=1, mode='danh-sach', is_search=False):
    domain = get_setting_domain()
    url = f"{domain}/v1/api/tim-kiem?keyword={slug}&page={page}" if is_search else f"{domain}/v1/api/{mode}/{slug}?page={page}"
        
    data = get_data(url)
    if data and data.get('status') == 'success':
        items = data['data'].get('items', [])
        cdn = data['data'].get('APP_DOMAIN_CDN_IMAGE', '') + "/upload/vod/"
        
        for m in items:
            li = xbmcgui.ListItem(label=m['name'])
            img = m['poster_url'] if m['poster_url'].startswith('http') else cdn + m['poster_url']
            li.setArt({'thumb': img, 'poster': img})
            li.setInfo('video', {'title': m['name'], 'year': m.get('year', '')})
            xbmcplugin.addDirectoryItem(HANDLE, f"{URL_SCRIPT}?action=list_episodes&slug={m['slug']}", li, True)
        
        if len(items) >= 10:
            next_url = f"{URL_SCRIPT}?action=list_movies&mode={mode}&slug={slug}&page={int(page)+1}"
            if is_search: next_url += "&is_search=true"
            xbmcplugin.addDirectoryItem(HANDLE, next_url, xbmcgui.ListItem(label=">> TRANG KẾ TIẾP"), True)

    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.endOfDirectory(HANDLE)

def list_episodes(slug, range_idx=None):
    domain = get_setting_domain()
    step = get_setting_ep_step()
    if step <= 0: step = 50

    data = get_data(f"{domain}/phim/{slug}")
    if not data or not data.get('status'): return

    movie = data['movie']
    try:
        history = json.loads(ADDON.getSetting('history') or '[]')
        history = [item for item in history if item['slug'] != slug]
        history.insert(0, {'name': movie['name'], 'slug': slug})
        ADDON.setSetting('history', json.dumps(history[:10]))
    except: pass

    if not data.get('episodes'): return
    server = data['episodes'][0]
    episodes = server.get('server_data', [])
    total_eps = len(episodes)
    thumb = movie.get('thumb_url', '')

    if total_eps > step and range_idx is None:
        for i in range(0, total_eps, step):
            start = i + 1
            end = min(i + step, total_eps)
            li = xbmcgui.ListItem(label=f">> Tập {start} - {end}")
            li.setArt({'thumb': thumb, 'poster': thumb})
            url = f"{URL_SCRIPT}?action=list_episodes&slug={slug}&range_idx={i}"
            xbmcplugin.addDirectoryItem(HANDLE, url, li, True)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    start_idx = int(range_idx) if range_idx is not None else 0
    display_eps = episodes[start_idx : start_idx + step]

    for ep in display_eps:
        li = xbmcgui.ListItem(label=f"Tập {ep['name']}")
        li.setInfo('video', {'title': f"{movie['name']} - Tập {ep['name']}", 'plot': movie.get('content', '')})
        li.setArt({'thumb': thumb, 'poster': thumb})
        li.setProperty('IsPlayable', 'true')
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        xbmcplugin.addDirectoryItem(HANDLE, ep['link_m3u8'], li, False)

    xbmcplugin.setContent(HANDLE, 'episodes')
    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    params = urllib.parse.parse_qs(sys.argv[2][1:])
    action = params.get('action', [None])[0]
    slug = params.get('slug', [None])[0]
    mode = params.get('mode', ['danh-sach'])[0]
    page = params.get('page', ['1'])[0]
    range_idx = params.get('range_idx', [None])[0]

    if action == 'search':
        if slug: list_movies(slug, page, is_search=True)
        else:
            kb = xbmc.Keyboard('', 'Nhập tên phim cần tìm...')
            kb.doModal()
            if kb.isConfirmed() and kb.getText():
                list_movies(urllib.parse.quote_plus(kb.getText()), page=1, is_search=True)
    elif action == 'list_latest':
        list_latest_movies(page)
    elif action == 'browse':
        browse_categories(params.get('type', ['the-loai'])[0])
    elif action == 'list_movies':
        list_movies(slug, page, mode, params.get('is_search', [None])[0])
    elif action == 'list_episodes':
        list_episodes(slug, range_idx)
    elif action == 'open_settings':
        ADDON.openSettings()
    else:
        list_main_menu()

