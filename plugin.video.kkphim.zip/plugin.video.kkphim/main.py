# -*- coding: utf-8 -*-
import sys
import json
import urllib.request
import urllib.parse
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmc

# --- KHỞI TẠO ADD-ON ---
ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
URL_SCRIPT = sys.argv[0]

def get_setting(id):
    return ADDON.getSetting(id)

def get_data(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            return json.loads(response.read().decode('utf-8'))
    except Exception as e:
        xbmc.log(f"[KKPHIM_ERROR]: {str(e)}", xbmc.LOGERROR)
        return None

def add_item(label, is_folder=True, **kwargs):
    url = f"{URL_SCRIPT}?{urllib.parse.urlencode(kwargs)}"
    li = xbmcgui.ListItem(label=label)
    xbmcplugin.addDirectoryItem(HANDLE, url, li, is_folder)

# --- MENU CHÍNH ---
def list_main_menu():
    add_item("[ 🔍 TÌM KIẾM PHIM ]", action='search')
    add_item("[ 🔥 PHIM MỚI CẬP NHẬT ]", action='list_latest', page='1')
    add_item("[ 📂 XEM THEO THỂ LOẠI ]", action='browse', type='the-loai')
    add_item("[ 🌍 XEM THEO QUỐC GIA ]", action='browse', type='quoc-gia')
    add_item("[ ⚙️ CÀI ĐẶT HỆ THỐNG ]", action='open_settings', is_folder=False)
    
    try:
        history_str = get_setting('history')
        if history_str:
            history = json.loads(history_str)
            if history:
                add_item("--- PHIM ĐÃ XEM GẦN ĐÂY ---", is_folder=False)
                for item in history:
                    add_item(f"🕒 {item['name']}", action='list_servers', slug=item['slug'])
    except: pass
    xbmcplugin.endOfDirectory(HANDLE)

# --- XỬ LÝ DANH SÁCH PHIM ---
def browse_categories(api_type):
    domain = get_setting('api_domain') or "https://phimapi.com"
    data = get_data(f"{domain}/{api_type}")
    if data:
        items = data if isinstance(data, list) else data.get('items', [])
        for item in items:
            add_item(item['name'], action='list_movies', mode=api_type, slug=item['slug'], page='1')
    xbmcplugin.endOfDirectory(HANDLE)

def list_movies(slug, page, mode, is_search=False):
    domain = get_setting('api_domain') or "https://phimapi.com"
    page = str(page)
    url = f"{domain}/v1/api/tim-kiem?keyword={slug}&page={page}" if is_search else f"{domain}/v1/api/{mode.replace('_', '-')}/{slug}?page={page}"

    data = get_data(url)
    if data and (data.get('status') == 'success' or 'data' in data):
        res = data.get('data', {})
        items = res.get('items', [])
        cdn = res.get('APP_DOMAIN_CDN_IMAGE', 'https://img.phimapi.com').rstrip('/') + "/upload/vod/"
        
        for m in items:
            li = xbmcgui.ListItem(label=m.get('name'))
            poster = m.get('poster_url', '')
            if poster and not poster.startswith('http'):
                poster = cdn + poster
            
            li.setArt({'thumb': poster, 'poster': poster, 'fanart': poster})
            # Thêm thông tin InfoLabel để Kodi nhận diện là nội dung Video
            li.setInfo('video', {'title': m.get('name'), 'year': m.get('year', ''), 'plot': m.get('content', '')})
            
            url_srv = f"{URL_SCRIPT}?{urllib.parse.urlencode({'action': 'list_servers', 'slug': m['slug']})}"
            xbmcplugin.addDirectoryItem(HANDLE, url_srv, li, True)
            
        if len(items) >= 10:
            add_item(">> TRANG KẾ TIẾP", action='list_movies', mode=mode, slug=slug, page=str(int(page)+1))
    
    # QUAN TRỌNG: Thiết lập content là 'movies' để mở khóa các View (Wall, Poster...)
    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.endOfDirectory(HANDLE)

def list_latest_movies(page):
    domain = get_setting('api_domain') or "https://phimapi.com"
    data = get_data(f"{domain}/danh-sach/phim-moi-cap-nhat?page={page}")
    if data and (data.get('status') is True or data.get('status') == 'success'):
        for m in data.get('items', []):
            li = xbmcgui.ListItem(label=m['name'])
            li.setArt({'thumb': m['thumb_url'], 'poster': m['poster_url'], 'fanart': m['poster_url']})
            li.setInfo('video', {'title': m['name']})
            url = f"{URL_SCRIPT}?{urllib.parse.urlencode({'action': 'list_servers', 'slug': m['slug']})}"
            xbmcplugin.addDirectoryItem(HANDLE, url, li, True)
        add_item(">> TRANG KẾ TIẾP", action='list_latest', page=str(int(page)+1))
    
    xbmcplugin.setContent(HANDLE, 'movies')
    xbmcplugin.endOfDirectory(HANDLE)

def list_servers(slug):
    domain = get_setting('api_domain') or "https://phimapi.com"
    data = get_data(f"{domain}/phim/{slug}")
    if not data or not data.get('status'): return
    movie = data['movie']
    
    try:
        history = json.loads(get_setting('history') or '[]')
        history = [i for i in history if i['slug'] != slug]
        history.insert(0, {'name': movie['name'], 'slug': slug})
        ADDON.setSetting('history', json.dumps(history[:10]))
    except: pass

    servers = data.get('episodes', [])
    if len(servers) > 1:
        for idx, srv in enumerate(servers):
            add_item(f"[COLOR yellow]▶ {srv.get('server_name')}[/COLOR]", action='list_episodes', slug=slug, srv_idx=str(idx))
    elif len(servers) == 1:
        list_episodes(slug, srv_idx='0')
    xbmcplugin.endOfDirectory(HANDLE)

def list_episodes(slug, srv_idx='0', range_idx=None):
    domain = get_setting('api_domain') or "https://phimapi.com"
    data = get_data(f"{domain}/phim/{slug}")
    if not data: return
    movie = data['movie']
    server_data = data['episodes'][int(srv_idx)]['server_data']
    total = len(server_data)
    
    idx_cfg = get_setting('ep_per_page')
    steps = [25, 50, 75, 100]
    step = steps[int(idx_cfg)] if (idx_cfg and idx_cfg.isdigit()) else 50

    if total > step and range_idx is None:
        for i in range(0, total, step):
            label = f">> Danh sách tập {i+1} - {min(i+step, total)}"
            add_item(label, action='list_episodes', slug=slug, srv_idx=srv_idx, range_idx=str(i))
        xbmcplugin.endOfDirectory(HANDLE)
        return

    start = int(range_idx) if range_idx else 0
    for ep in server_data[start : start + step]:
        display_name = ep.get('filename') if ep.get('filename') else ep.get('name')
        li = xbmcgui.ListItem(label=display_name)
        li.setArt({'thumb': movie.get('thumb_url'), 'poster': movie.get('poster_url')})
        li.setInfo('video', {'title': display_name, 'plot': movie.get('content', '')})
        li.setProperty('IsPlayable', 'true')
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        xbmcplugin.addDirectoryItem(HANDLE, ep['link_m3u8'], li, False)
    
    # Dành cho tập phim thì đặt là 'episodes'
    xbmcplugin.setContent(HANDLE, 'episodes')
    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    if action == 'search':
        kb = xbmc.Keyboard('', 'Tìm phim...')
        kb.doModal()
        if kb.isConfirmed() and kb.getText():
            list_movies(urllib.parse.quote_plus(kb.getText()), '1', 'the-loai', is_search=True)
    elif action == 'list_latest': list_latest_movies(params.get('page', '1'))
    elif action == 'browse': browse_categories(params.get('type'))
    elif action == 'list_movies': list_movies(params.get('slug'), params.get('page', '1'), params.get('mode'), params.get('is_search'))
    elif action == 'list_servers': list_servers(params.get('slug'))
    elif action == 'list_episodes': list_episodes(params.get('slug'), params.get('srv_idx', '0'), params.get('range_idx'))
    elif action == 'open_settings': ADDON.openSettings()
    else: list_main_menu()
